# CV
# Lenny
A skill professional with over 11 years experience in finance & accounting, procurement, and logistic. Expertise in managing financial operations, tax compliance, financial reporting and maintaining supplier relationships. Proficient in accounts payable/receivable, payroll administration, bank reconciliations, and financial software. Strong communicator with problem solving and organizational skills, alming to leverage this experience in a dynamic finance and accounting role

## Education
Pelita Indonesia
-   Accounting / 3.37

### Experiences
-   PT. Winn Appliance (Assistant Finance Manager)
-   PT. Sumber Berkat Dwitunggal (Operational Deputy)
- PT. Pasar Buah 88 (Finance & Accounting)
